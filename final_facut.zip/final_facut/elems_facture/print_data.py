def print_data(factureDate, numeroFacture, montantTotal, tva, montantHt):
    print()
    print ("Date de facture:", factureDate)
    print("Numero de facture:", numeroFacture)

    print("Fournisseur:")
    print ("Montant Total HTTC:", montantTotal)
    print("Montant TVA:", tva)
    print("Montant HT", montantHt)
